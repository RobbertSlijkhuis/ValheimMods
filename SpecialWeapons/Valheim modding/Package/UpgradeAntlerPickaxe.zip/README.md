A simple mod to allow upgrades for the antler pickaxe. Using the upgrade materials/amounts already set by the game itself.
Also added some special weapons for my friends as I want to use this on my own server, these are disabled by default.

## The special weapons will be moved to a seperate mod soon!